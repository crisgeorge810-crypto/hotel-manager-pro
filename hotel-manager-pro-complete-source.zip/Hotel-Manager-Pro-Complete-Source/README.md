# Hotel Manager Pro — source foundation release

This ZIP contains a working, local-first PMS foundation and Windows desktop wrapper.

## Included now
- Responsive navy/gold dashboard and navigation across the 18 planned operational areas.
- Local browser storage for records.
- Add records and edit grid cells in place.
- CSV import/export per module for spreadsheet workflows.
- JSON full-workspace backup and restore.
- Hotel profile settings and local activity timestamps.
- Starter written training guide.
- PWA shell/offline caching.
- Electron Windows NSIS installer and portable EXE build workflow.

## Important implementation boundary
This is **not yet a production-ready, complete enterprise PMS**. Some modules currently provide record registers and starter workflows, not full business logic. In particular, reservation overlap prevention, automated check-in/out state transitions, room-calendar scheduling, restaurant-to-folio posting, recipe-driven stock deduction, purchase receiving, tax/accounting rules, role permissions, secure multi-hotel tenancy, cloud synchronization, license enforcement, online payment gateways, and OTA APIs still require implementation and tests.

The current local prototype stores data in the browser's localStorage. It is not suitable for sensitive live guest records or multi-user production use. Do not enter real guest identity/payment data until secure backend authentication, tenant isolation, access policies, audit enforcement, backups and privacy controls have been implemented and reviewed.

## Run as a web app
Serve this folder over HTTPS or localhost. Open `index.html` for a quick preview; service-worker/PWA features require localhost or HTTPS.

## Build Windows installer and portable EXE
1. Install Node.js 22 or newer.
2. Run `npm install`.
3. Run `npm run dist`.
4. Outputs are created under `dist/`.
5. Or push the source to GitHub and run **Build Hotel Manager Pro for Windows** in Actions.

The EXE is unsigned unless you separately configure a code-signing certificate.

## GitHub upload using the included workflow
1. Upload `hotel-manager-pro-source.zip` to the root of the existing repository. Keep `hotel-manager-pro-full-replacement.zip` unchanged.
2. Ensure the workflow `.github/workflows/install-source-package.yml` has been added to the repository (or create it from this package).
3. Run **Install Hotel Manager Pro Source Package** from GitHub Actions.
4. Review the commit and run the Windows build workflow.
5. Test the generated artifact before treating it as a release.

## Next engineering milestones
1. Move local records to a versioned IndexedDB repository and add migration tests.
2. Build secure Supabase Auth onboarding and tenant-scoped RLS policies; review policies before enabling production access.
3. Implement transactional reservation availability and visual room timeline.
4. Implement folios, POS/kitchen workflow, stock ledger, recipes and purchasing as linked transactions.
5. Add staff roles/permissions, immutable audit events, subscriptions/licensing and cloud backup.
6. Add complete role-specific manuals and recorded video tutorials.
7. Add integration adapters for payment providers and OTA/channel manager APIs after credentials and contracts are available.
